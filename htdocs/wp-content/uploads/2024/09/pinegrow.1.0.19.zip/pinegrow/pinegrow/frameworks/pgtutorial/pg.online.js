$(function(){$("body").one("pinegrow-ready",function(t,n){n.addEventHandler("on_get_actions_for_start_menu",function(t,e){var o=[],i=(o.push({icon:`<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-camera-reels" viewBox="0 0 16 16">
<path d="M6 3a3 3 0 1 1-6 0 3 3 0 0 1 6 0zM1 3a2 2 0 1 0 4 0 2 2 0 0 0-4 0z"/>
<path d="M9 6h.5a2 2 0 0 1 1.983 1.738l3.11-1.382A1 1 0 0 1 16 7.269v7.462a1 1 0 0 1-1.406.913l-3.111-1.382A2 2 0 0 1 9.5 16H2a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h7zm6 8.73V7.27l-3.5 1.555v4.35l3.5 1.556zM1 8v6a1 1 0 0 0 1 1h7.5a1 1 0 0 0 1-1V8a1 1 0 0 0-1-1H2a1 1 0 0 0-1 1z"/>
<path d="M9 6a3 3 0 1 0 0-6 3 3 0 0 0 0 6zM7 3a2 2 0 1 1 4 0 2 2 0 0 1-4 0z"/>
</svg>`,label:"Watch the intro video",desc:"Learn everything you need to get started.",class:"pg-lessons-intro-video",action:function(){new PgTutorialVideo("780916966",`1
00:00:00,420 --> 00:00:02,730
Hi, Matjaz from Pinegrow here.

2
00:00:03,300 --> 00:00:07,980
Thank you for installing Pinegrow plugin on your WordPress site.

3
00:00:08,640 --> 00:00:15,420
With Pinegrow, you can easily build custom
Gutenberg blocks and whole WordPress themes.

4
00:00:16,540 --> 00:00:21,750
Pinegrow creates plugins and themes that don't require Pinegrow to run.

5
00:00:22,620 --> 00:00:29,600
After you export your project, you can deactivate
or even delete Pinegrow plugin from your site.

6
00:00:30,110 --> 00:00:34,065
Pinegrow plugin comes in two editions: free and PRO.

7
00:00:34,785 --> 00:00:38,685
The free edition is great for building simple custom blocks.

8
00:00:39,735 --> 00:00:53,055
The PRO edition offers much more: the ability to build blocks with sub
blocks, creating whole themes, WooCommerce integration, GreenSock powered

9
00:00:53,055 --> 00:00:58,595
interactions, and the ability to export and import source projects.

10
00:00:59,310 --> 00:01:03,300
And not to mention, email support with our team.

11
00:01:04,380 --> 00:01:14,490
The best place to start is to do the interactive tutorial "Build
your first block" by going through these short fun lessons.

12
00:01:15,000 --> 00:01:28,310
You will learn how to build HTML structure, style it with CSS, and then add
WordPress features to create blocks that can be used on any WordPress site.

13
00:01:28,930 --> 00:01:34,425
Along the way, you will also become familiar with Pinegrow user interface.

14
00:01:35,205 --> 00:01:41,264
In about an hour, you will know enough to start building your own custom blocks.

15
00:01:41,955 --> 00:01:50,354
That's a superpower that gives you freedom to build
whatever you and your clients need without being limited

16
00:01:50,354 --> 00:01:54,695
by page builders, plugins, or WordPress features.

17
00:01:55,635 --> 00:02:00,105
You can continue  to use your favorite page builders and plugins, of course.

18
00:02:00,765 --> 00:02:08,354
Pinegrow can be used alongside other tools to
easily implement custom features for your projects.

19
00:02:09,854 --> 00:02:20,055
And if you want to go deeper into what you can do with Pinegrow, we
have lots of tutorials and documentation available on our website.

20
00:02:20,805 --> 00:02:22,085
Welcome to Pinegrow!

`)}}),{icon:`<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-map" viewBox="0 0 16 16">
  <path fill-rule="evenodd" d="M15.817.113A.5.5 0 0 1 16 .5v14a.5.5 0 0 1-.402.49l-5 1a.502.502 0 0 1-.196 0L5.5 15.01l-4.902.98A.5.5 0 0 1 0 15.5v-14a.5.5 0 0 1 .402-.49l5-1a.5.5 0 0 1 .196 0L10.5.99l4.902-.98a.5.5 0 0 1 .415.103zM10 1.91l-4-.8v12.98l4 .8V1.91zm1 12.98 4-.8V1.11l-4 .8v12.98zm-6-.8V1.11l-4 .8v12.98l4-.8z"/>
</svg>`,label:"Pinegrow Academy",desc:"Learn how to get started and get the most out of Pinegrow.",url:"https://pinegrow.com/docs/wordpress/"}),i=(o.push(i),{icon:`<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-chat" viewBox="0 0 16 16">
  <path d="M2.678 11.894a1 1 0 0 1 .287.801 10.97 10.97 0 0 1-.398 2c1.395-.323 2.247-.697 2.634-.893a1 1 0 0 1 .71-.074A8.06 8.06 0 0 0 8 14c3.996 0 7-2.807 7-6 0-3.192-3.004-6-7-6S1 4.808 1 8c0 1.468.617 2.83 1.678 3.894zm-.493 3.905a21.682 21.682 0 0 1-.713.129c-.2.032-.352-.176-.273-.362a9.68 9.68 0 0 0 .244-.637l.003-.01c.248-.72.45-1.548.524-2.319C.743 11.37 0 9.76 0 8c0-3.866 3.582-7 8-7s8 3.134 8 7-3.582 7-8 7a9.06 9.06 0 0 1-2.347-.306c-.52.263-1.639.742-3.468 1.105z"/>
</svg>`,label:"Join the community",desc:"Interact with Pinegrow users and the team.",action:function(){var t=[];n.currentUser.isPro()||t.push({icon:`<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-envelope-fill" viewBox="0 0 16 16">
  <path d="M.05 3.555A2 2 0 0 1 2 2h12a2 2 0 0 1 1.95 1.555L8 8.414.05 3.555ZM0 4.697v7.104l5.803-3.558L0 4.697ZM6.761 8.83l-6.57 4.027A2 2 0 0 0 2 14h12a2 2 0 0 0 1.808-1.144l-6.57-4.027L8 9.586l-1.239-.757Zm3.436-.586L16 11.801V4.697l-5.803 3.546Z"/>
</svg>`,label:"E-mail newsletter",desc:"The best way to stay in the loop.",url:"https://pinegrow.com#footer",action:function(){}}),t.push({icon:`<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-chat-fill" viewBox="0 0 16 16">
  <path d="M8 15c4.418 0 8-3.134 8-7s-3.582-7-8-7-8 3.134-8 7c0 1.76.743 3.37 1.97 4.6-.097 1.016-.417 2.13-.771 2.966-.079.186.074.394.273.362 2.256-.37 3.597-.938 4.18-1.234A9.06 9.06 0 0 0 8 15z"/>
</svg>`,label:"Community forum",desc:"The best place for getting help, reporting issues and staying in touch with the team.",url:"https://forum.pinegrow.com",action:function(){}}),t.push({icon:`<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-youtube" viewBox="0 0 16 16">
  <path d="M8.051 1.999h.089c.822.003 4.987.033 6.11.335a2.01 2.01 0 0 1 1.415 1.42c.101.38.172.883.22 1.402l.01.104.022.26.008.104c.065.914.073 1.77.074 1.957v.075c-.001.194-.01 1.108-.082 2.06l-.008.105-.009.104c-.05.572-.124 1.14-.235 1.558a2.007 2.007 0 0 1-1.415 1.42c-1.16.312-5.569.334-6.18.335h-.142c-.309 0-1.587-.006-2.927-.052l-.17-.006-.087-.004-.171-.007-.171-.007c-1.11-.049-2.167-.128-2.654-.26a2.007 2.007 0 0 1-1.415-1.419c-.111-.417-.185-.986-.235-1.558L.09 9.82l-.008-.104A31.4 31.4 0 0 1 0 7.68v-.123c.002-.215.01-.958.064-1.778l.007-.103.003-.052.008-.104.022-.26.01-.104c.048-.519.119-1.023.22-1.402a2.007 2.007 0 0 1 1.415-1.42c.487-.13 1.544-.21 2.654-.26l.17-.007.172-.006.086-.003.171-.007A99.788 99.788 0 0 1 7.858 2h.193zM6.4 5.209v4.818l4.157-2.408L6.4 5.209z"/>
</svg>`,label:"YouTube",desc:"Subscribe to watch tutorials and product announcement videos.",url:"https://www.youtube.com/channel/UCo2RGSbsI9GIxVvJPXanUuw",action:function(){}}),t.push({icon:`<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-facebook" viewBox="0 0 16 16">
  <path d="M16 8.049c0-4.446-3.582-8.05-8-8.05C3.58 0-.002 3.603-.002 8.05c0 4.017 2.926 7.347 6.75 7.951v-5.625h-2.03V8.05H6.75V6.275c0-2.017 1.195-3.131 3.022-3.131.876 0 1.791.157 1.791.157v1.98h-1.009c-.993 0-1.303.621-1.303 1.258v1.51h2.218l-.354 2.326H9.25V16c3.824-.604 6.75-3.934 6.75-7.951z"/>
</svg>`,label:"Facebook",desc:"The official Pinegrow page on Facebook.",url:"https://www.facebook.com/pinegrow",action:function(){}}),t.push({icon:`<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-twitter" viewBox="0 0 16 16">
  <path d="M5.026 15c6.038 0 9.341-5.003 9.341-9.334 0-.14 0-.282-.006-.422A6.685 6.685 0 0 0 16 3.542a6.658 6.658 0 0 1-1.889.518 3.301 3.301 0 0 0 1.447-1.817 6.533 6.533 0 0 1-2.087.793A3.286 3.286 0 0 0 7.875 6.03a9.325 9.325 0 0 1-6.767-3.429 3.289 3.289 0 0 0 1.018 4.382A3.323 3.323 0 0 1 .64 6.575v.045a3.288 3.288 0 0 0 2.632 3.218 3.203 3.203 0 0 1-.865.115 3.23 3.23 0 0 1-.614-.057 3.283 3.283 0 0 0 3.067 2.277A6.588 6.588 0 0 1 .78 13.58a6.32 6.32 0 0 1-.78-.045A9.344 9.344 0 0 0 5.026 15z"/>
</svg>`,label:"Twitter",url:"https://twitter.com/pinegrow",desc:"Follow Pinegrow on Twitter.",action:function(){}}),n.showDialogMenu(`Join the Pinegrow community`,`Stay in touch with Pinegrow users and the team:`,t)}});o.push(i),n.currentUser.isPro()?o.push({icon:`<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-envelope" viewBox="0 0 16 16">
  <path d="M0 4a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V4Zm2-1a1 1 0 0 0-1 1v.217l7 4.2 7-4.2V4a1 1 0 0 0-1-1H2Zm13 2.383-4.708 2.825L15 11.105V5.383Zm-.034 6.876-5.64-3.471L8 9.583l-1.326-.795-5.64 3.47A1 1 0 0 0 2 13h12a1 1 0 0 0 .966-.741ZM1 11.105l4.708-2.897L1 5.383v5.722Z"/>
</svg>`,label:"Contact support",desc:"Get E-mail support from the Pinegrow team.",url:"https://pinegrow.com/docs/wordpress/pinegrow-wordpress-plugin/#contact-support",action:function(){}}):(i={icon:`<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-rocket-takeoff" viewBox="0 0 16 16">
  <path d="M9.752 6.193c.599.6 1.73.437 2.528-.362.798-.799.96-1.932.362-2.531-.599-.6-1.73-.438-2.528.361-.798.8-.96 1.933-.362 2.532Z"/>
  <path d="M15.811 3.312c-.363 1.534-1.334 3.626-3.64 6.218l-.24 2.408a2.56 2.56 0 0 1-.732 1.526L8.817 15.85a.51.51 0 0 1-.867-.434l.27-1.899c.04-.28-.013-.593-.131-.956a9.42 9.42 0 0 0-.249-.657l-.082-.202c-.815-.197-1.578-.662-2.191-1.277-.614-.615-1.079-1.379-1.275-2.195l-.203-.083a9.556 9.556 0 0 0-.655-.248c-.363-.119-.675-.172-.955-.132l-1.896.27A.51.51 0 0 1 .15 7.17l2.382-2.386c.41-.41.947-.67 1.524-.734h.006l2.4-.238C9.005 1.55 11.087.582 12.623.208c.89-.217 1.59-.232 2.08-.188.244.023.435.06.57.093.067.017.12.033.16.045.184.06.279.13.351.295l.029.073a3.475 3.475 0 0 1 .157.721c.055.485.051 1.178-.159 2.065Zm-4.828 7.475.04-.04-.107 1.081a1.536 1.536 0 0 1-.44.913l-1.298 1.3.054-.38c.072-.506-.034-.993-.172-1.418a8.548 8.548 0 0 0-.164-.45c.738-.065 1.462-.38 2.087-1.006ZM5.205 5c-.625.626-.94 1.351-1.004 2.09a8.497 8.497 0 0 0-.45-.164c-.424-.138-.91-.244-1.416-.172l-.38.054 1.3-1.3c.245-.246.566-.401.91-.44l1.08-.107-.04.039Zm9.406-3.961c-.38-.034-.967-.027-1.746.163-1.558.38-3.917 1.496-6.937 4.521-.62.62-.799 1.34-.687 2.051.107.676.483 1.362 1.048 1.928.564.565 1.25.941 1.924 1.049.71.112 1.429-.067 2.048-.688 3.079-3.083 4.192-5.444 4.556-6.987.183-.771.18-1.345.138-1.713a2.835 2.835 0 0 0-.045-.283 3.078 3.078 0 0 0-.3-.041Z"/>
  <path d="M7.009 12.139a7.632 7.632 0 0 1-1.804-1.352A7.568 7.568 0 0 1 3.794 8.86c-1.102.992-1.965 5.054-1.839 5.18.125.126 3.936-.896 5.054-1.902Z"/>
</svg>`,label:"Activate Pinegrow Pro",desc:"Buy or activate your Pinegrow Pro license.",action:function(){},url:pgwpdata.settings_url||pgf.buy_url},o.push(i)),o.forEach(function(t){e.push(t)})}),n.addEventHandler("on_get_new_project_templates",function(t,e){[{name:"Blank Plain HTML Project",pid:"https://tutorial_new_html",thumb:"blank_html.png",desc:"Sometimes HTML &amp; CSS is all you need.",vid:"",subid:""},{name:"Blank Bootstrap 5 Project",pid:"https://tutorial_new_bs",thumb:"blank_bootstrap.jpg",desc:"Bootstrap 5 with Design panel and Blocks.",vid:"",subid:""},{name:"Blank Tailwind CSS Project",pid:"https://tutorial_new_tw",thumb:"blank_tailwind.png",desc:"Tailwind CSS with Design panel and Blocks.",vid:"",subid:""}].forEach(function(t){t.thumb=`images/project_templates/`+t.thumb,e.push(t)})})})});