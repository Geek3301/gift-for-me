(function( $ ) {
	'use strict';

})( jQuery );
